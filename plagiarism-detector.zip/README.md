Udacity - Machine Learning Engineer Nanodegree
Project: Plagiarism detector project

Project Aim


Building a plagiarism detector that examines a text file and then applies binary classification with the purpose to labeling that file either plagiarized or not;

Software and Libraries
The project utilizes mainly the following software and Python libraries:

-Python
-NumPy
-Pandas
-Scikit-learn
-Amazon SageMaker
